<html>
<head>
<title>Gateway</title>

<link rel="stylesheet" type="text/css" href="admin/assets/css/Material+Icons.css" />
</head>
<body bgcolor="linen">
    <center>
        <h1>Now Your Order Payment Will Handle by Payment Gateway</h1>
        <h2><button><a href="index.php"><i class='material-icons'>home</i></a></button></h2>
        </center>
</body>
</htm>