<?php

include "header.php";


if(isset($_POST['search_btn']))
{
   $search = $_POST['search'];
   if($search=="")
   {
       include "body.php";
   }
   else
   {
   include "db.php";
    $sql = "SELECT * FROM products WHERE product_title LIKE '%$search%' OR product_desc LIKE '%$search%' OR product_keywords LIKE '%$search%'";
    $run_query = mysqli_query($con,$sql);
    $num = mysqli_num_rows($run_query);
    if($num != 0)
    {
        echo"<div class='main main-raised'>
        <div class='section'>
        <div class='container'>
        <div class='row'>
        <div class='row' id='product-row'>";

	while($row=mysqli_fetch_array($run_query))
    {
			$pro_id    = $row['product_id'];
			$pro_cat   = $row['cat_id'];
			$pro_title = $row['product_title'];
			$pro_price = $row['product_price'];
			$pro_image = $row['product_image'];
            $sql1 = "SELECT * FROM categories WHERE cat_id=$pro_cat";
            $run_query1 = mysqli_query($con,$sql1);
            $num1 = mysqli_num_rows($run_query1);
            while($row1=mysqli_fetch_array($run_query1))
            {
                    $cat_id = $row1['cat_id'];
                    $cat_title = $row1['cat_title'];
			echo "
            <div class='col-md-4 col-xs-8'>
            <a href='product.php?p=$pro_id'><div class='product'>
                <div class='product-img'>
                    <img  src='product_images/$pro_image'  style='max-height: 170px;' alt=''>
                    <!--<div class='product-label'>
                        <span class='sale'>-30%</span>
                        <span class='new'>NEW</span>
                    </div>--><br><br>
                </div></a>
                <div class='product-body'>
                <p class='product-category'>$cat_title</p>
                            <h3 class='product-name header-cart-item-name'><a href='product.php?p=$pro_id'>$pro_title</a></h3>
                    <h4 class='product-price header-cart-item-info'>₹$pro_price<!--<del class='product-old-price'>₹990.00</del>--></h4>
                    <div class='product-rating'>
                        <i class='fa fa-star'></i>
                        <i class='fa fa-star'></i>
                        <i class='fa fa-star'></i>
                        <i class='fa fa-star'></i>
                        <i class='fa fa-star'></i>
                    </div>
                    
                </div>
                <div class='add-to-cart'>
                    <button pid='$pro_id' id='product' href='#' tabindex='0' class='add-to-cart-btn'><i class='fa fa-shopping-cart'></i> Add to cart</button>
                </div>
            </div>
        </div>

           ";
            }
    }
    echo " </div></div></div></div>";
}
else
{
    echo "<div class='main main-raised'>
    <div class='section'>
    <div class='container'>
    <div class='row'><h2><center>try to again</center></h2><div></div></div></div>";
}
   }
}
else
{
    include "body.php";

}
include "footer.php";
?>
		
		