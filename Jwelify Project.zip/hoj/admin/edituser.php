<html>
  <head>
    <script>
       function dis()
        {
            if(document.form.mobile.value.length!=10)
            {
              alert("Mobile Enter in Proper Format");
              return false;
            }
            else if(document.form.password.value.length<8)
            {
              alert("Password is Weak");
              return false;
            }
            else
            {
              return true;
            }
        }
      </script>
</head>
</html>
    <?php
session_start();
include("../db.php");
$user_id=$_REQUEST['user_id'];

$result=mysqli_query($con,"select user_id,first_name,last_name, email,mobile,password from user_info where user_id='$user_id'")or die ("query 1 incorrect.......");

list($user_id,$first_name,$last_name,$email,$mobile,$password)=mysqli_fetch_array($result);
if (isset($_POST["btn_save"])) {
  $first_name = $_POST["first_name"];
	$last_name = $_POST["last_name"];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$mobile = $_POST['mobile'];

$sql = "UPDATE user_info SET first_name='$first_name', last_name='$last_name', email='$email',mobile='$mobile', password='$password' WHERE user_id='$user_id'" or die("Query 2 is inncorrect..........");
$run = mysqli_query($con,$sql);
header("location: sumit_form.php?success=1");
header("location: manageuser.php");
mysqli_close($con);
}
include "sidenav.php";
include "topheader.php";
echo'
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
        <div class="col-md-5 mx-auto">
            <div class="card">
              <div class="card-header card-header-primary">
                <h5 class="title">Edit User</h5>
              </div>
              <form action="edituser.php" name="form" method="post" enctype="multipart/form-data">
              <div class="card-body">
                
                  <input type="hidden" name="user_id" id="user_id" value="'.$user_id.'">
                    <div class="col-md-12 ">
                      <div class="form-group">
                        <label>First Name</label>
                        <input type="text" id="first_name" name="first_name"  pattern="^[a-zA-Z ]+$" required class="form-control" value="'.$first_name.'" >
                      </div>
                    </div>
                    <div class="col-md-12 ">
                      <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" id="last_name" name="last_name"  pattern="^[a-zA-Z ]+$" required class="form-control" value="'.$last_name.'" >
                      </div>
                    </div>
                    <div class="col-md-12 ">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Email Address</label>
                        <input type="email"  id="email" name="email" pattern="^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9]+(\.[a-z]{2,4})$" required class="form-control" value="'.$email.'">
                      </div>
                    </div>
                    <div class="col-md-12 ">
                    <div class="form-group">
                      <label>Mobile No</label>
                      <input type="number"  id="mobile" name="mobile" required pattern="^[0-9]+$" class="form-control" value="'.$mobile.'">
                    </div>
                  </div>
                
                    <div class="col-md-12 ">
                      <div class="form-group">
                        <label >Password</label>
                        <input type="text" name="password" id="password" required class="form-control" value="'.$password.'">
                      </div>
                    </div>
                  
                  
                  
                
              
              <div class="card-footer">
                <input type="submit" id="btn_save" name="btn_save" class="btn btn-fill btn-primary" value="Update" onclick="return dis()"/>
              </div>
              <div class="col-md-12 ">
              </form>    
            </div>
          </div>
         
          
        </div>
      </div>
';
include "footer.php";
?>