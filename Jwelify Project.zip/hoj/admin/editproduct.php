<html>
  <head>
   <script>
       function dis()
        {
            if(document.form.product_price.value.length>7)
            {
              alert("Price To Large");
              return false;
            } 
           // else if(document.form.product_cat.value.length!=1)
          // {
           //   alert("Invalid Category");
           //   return false;
          //  }
          //  else
          //  {
         //     return true;
         //   }
        }
      </script> 
</head>
</html>
    <?php
session_start();
include("../db.php");
$product_id=$_REQUEST['product_id'];

$result=mysqli_query($con,"select product_id,cat_id,product_title, product_price, product_desc,product_image , product_keywords from products where product_id='$product_id'")or die ("query 1 incorrect.......");

list($product_id,$product_cat,$product_title,$product_price,$product_desc,$pic_name,$product_keywords)=mysqli_fetch_array($result);

if(isset($_POST['btn_save'])) 
{

$product_title=$_POST['product_title'];
$product_price=$_POST['product_price'];
$product_desc=$_POST['product_desc'];
$product_keywords=$_POST['product_keywords'];
$product_cat=$_POST['product_cat'];

$picture_name=$_FILES['picture']['name'];
$picture_type=$_FILES['picture']['type'];
$picture_tmp_name=$_FILES['picture']['tmp_name'];
$picture_size=$_FILES['picture']['size'];

if($picture_type=="image/jpeg" || $picture_type=="image/jpg" || $picture_type=="image/png" || $picture_type=="image/gif")
{
	if($picture_size<=50000000)
	{
		$pic_name=time()."_".$picture_name;
		move_uploaded_file($picture_tmp_name,"../product_images/".$pic_name);
  }	

mysqli_query($con,"update products set product_title='$product_title', product_price='$product_price', product_desc='$product_desc', product_keywords='$product_keywords', cat_id='$product_cat', product_image='$pic_name' where product_id='$product_id'")or die("Query 2 is inncorrect..........");
}
header("location: productlist.php");
mysqli_close($con);
}
include "sidenav.php";
include "topheader.php";
?>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
        <div class="col-md-6 mx-auto">
            <div class="card">
              <div class="card-header card-header-primary">
                <h5 class="title">Edit Product</h5>
              </div>
              <div id="form">
              <form action="editproduct.php" name="form" method="post" enctype="multipart/form-data">
              <div class="card-body">
                
                  <input type="hidden" name="product_id" id="product_id" value="<?php echo $product_id;?>"/>
                    <div class="col-md-12 ">
                      <div class="form-group">
                        <label>Title</label>
                        <input type="text" id="product_title"  name="product_title" required class="form-control" value="<?php echo $product_title; ?>">
                      </div>
                    </div>
                    <div class="col-md-12 ">
                      <div class="form-group">
                        <label>Price</label>
                        <input type="number" id="product_price" name="product_price" required pattern="^[0-9]+$"  class="form-control" value="<?php echo $product_price; ?>">
                      </div>
                    </div>
                    <div class="col-md-12 ">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Description</label>
                        <input type="text"  id="product_desc" name="product_desc" required  class="form-control" value="<?php echo $product_desc; ?>">
                      </div>
                    </div>
                    <div class="col-md-12 ">
                      <div class="form-group">
                        <label>Keyword</label>
                        <input type="text" name="product_keywords" id="product_keywords" required pattern="^[0-9a-zA-Z ]+$" class="form-control" value="<?php echo $product_keywords; ?>">
                      </div>
                    </div>
                    <div class="col-md-12">
                      <div class="">
                        <label for="">Add Image</label><br>
                        <input type="file" name="picture" required class="btn btn-fill btn-success" id="picture" value="<?php echo $pic_name;?>"><br><br>
                      </div>
                    </div>
                   
                  
                  <div class="col-md-12 ">
                      <div class="form-group">
                        <label>Category</label>
                        <input type="number" name="product_cat" id="product_cat" required="[1-7]" pattern="^[0-9]+$" class="form-control" value="<?php echo $product_cat	; ?>">
                      </div>
                    </div>
					 
</div>  
                
              </div>
              <div class="card-footer">
                <input type="submit" id="btn_save" name="btn_save" class="btn btn-fill btn-primary" onclick="return dis()" value="Update"/>
              </div>
              </form>    
            </div>
          </div>
         
          
        </div>
      </div>
      <?php
include "footer.php";
?>