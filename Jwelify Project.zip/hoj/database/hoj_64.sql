-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 11, 2025 at 07:31 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hoj_64`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `getcat` (IN `cid` INT)   SELECT * FROM categories WHERE cat_id=cid$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_info`
--

CREATE TABLE `admin_info` (
  `admin_id` int(2) NOT NULL,
  `admin_name` text NOT NULL,
  `admin_email` text NOT NULL,
  `admin_password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin_info`
--

INSERT INTO `admin_info` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(2, 'Alakh', 'alakh@hoj.gmail.com', 'hoj@jj64');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(4) NOT NULL,
  `p_id` int(4) NOT NULL,
  `user_id` int(5) DEFAULT NULL,
  `qty` int(2) NOT NULL,
  `ip_add` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `p_id`, `user_id`, `qty`, `ip_add`) VALUES
(30, 56, 40, 1, '::1'),
(31, 58, 42, 1, '::1'),
(45, 34, 44, 1, '::1'),
(46, 51, 45, 1, '::1'),
(48, 26, 48, 1, '::1'),
(50, 34, 50, 1, '::1'),
(52, 26, 51, 1, '::1'),
(54, 15, 2, 1, '::1'),
(55, 31, 52, 1, '::1'),
(57, 1, 53, 1, '::1'),
(58, 71, 29, 1, '::1'),
(64, 3, 54, 1, '::1');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(2) NOT NULL,
  `cat_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'Earrings'),
(2, 'Pendants'),
(3, 'Rings'),
(4, 'Mangalsutra'),
(5, 'Necklaces'),
(6, 'Bangles'),
(7, 'Chains');

-- --------------------------------------------------------

--
-- Table structure for table `orders_info`
--

CREATE TABLE `orders_info` (
  `order_id` int(4) NOT NULL,
  `user_id` int(5) NOT NULL,
  `prod_count` int(2) DEFAULT NULL,
  `total_amt` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `orders_info`
--

INSERT INTO `orders_info` (`order_id`, `user_id`, `prod_count`, `total_amt`) VALUES
(4, 29, 2, 165910),
(5, 39, 1, 249120),
(6, 50, 1, 17780),
(7, 51, 1, 565),
(8, 54, 1, 17240),
(9, 54, 2, 89915),
(10, 54, 1, 91147),
(11, 55, 1, 91147),
(12, 55, 1, 120000);

-- --------------------------------------------------------

--
-- Table structure for table `order_products`
--

CREATE TABLE `order_products` (
  `order_pro_id` int(4) NOT NULL,
  `order_id` int(4) NOT NULL,
  `product_id` int(4) NOT NULL,
  `qty` int(2) DEFAULT NULL,
  `amt` int(7) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `order_products`
--

INSERT INTO `order_products` (`order_pro_id`, `order_id`, `product_id`, `qty`, `amt`) VALUES
(7, 4, 25, 1, 101260),
(8, 4, 51, 1, 64650),
(9, 5, 50, 2, 498240),
(10, 6, 27, 1, 17780),
(11, 7, 57, 1, 565),
(12, 8, 15, 1, 17240),
(13, 9, 1, 1, 19790),
(14, 9, 2, 1, 70125),
(15, 10, 3, 1, 91147),
(16, 11, 3, 1, 91147),
(17, 12, 72, 1, 120000);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(4) NOT NULL,
  `cat_id` int(2) NOT NULL,
  `product_title` text NOT NULL,
  `product_price` int(7) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `cat_id`, `product_title`, `product_price`, `product_desc`, `product_image`, `product_keywords`) VALUES
(1, 1, 'goldsplendid gold drop', 19790, 'Gross Weight : 5.584g  Women 18 Karat Glossy Yellow Gold Making Charges : 2310.00 + GST 1250.00 Included', '1648997628_earrings9.jpg', 'earrings'),
(2, 1, 'dazzling diamond ear studs', 70125, '14 Karat Gold Height 22.7 MM Product Width 22.9 MM', '1648997152_erarrings9.jpg', 'earrings'),
(3, 1, 'alluring  yellow gold leaf drops', 91147, 'Gross Weight : 11.584g  Women 22 Karat Making Charges : 12870.00 + GST 1347.00 Included   Height 44.00 MM Product Width 14.00 MM', '1649001323_earrings11.jpg', 'earrings'),
(4, 1, 'elaborate diamond round stud earrings', 419247, 'Gross Weight : 9.014g[18 Karat Rose Gold]  Stone Detail : 2.1 ct[Stone Clarity Si2]  Making Charges : 84640.00 + GST 11247.00 Included', '1649001952_earrings12.jpg', 'earrings'),
(13, 2, 'intricate  gold pendant with spokes', 227230, 'Gross Weight : 13.474g[22 karat yellow]  Making Charges : 95640.00 + GST 14270.00 Included', '1649003285_pendant1.jpg', 'pendant'),
(14, 2, 'ornate gold and diamond lakshmi pendant', 229130, 'Gross Weight : 10.850g[18 karat yellow]  Diamond Weight: 1.052 ct[Stone Clarity: SI2]  Height   Making Charges : 47640.00 + GST 6770.00 Included 38 MM Product Width 25 MM  ', '1649004195_pendant2.jpg', 'pendant'),
(15, 2, 'dual toned om gold pendant', 17240, 'Gross Weight : 2.750g[22 Karat Yellow Gold]   Height 25 MM Product Width 16 MM  Making Charges : 2740.00 + GST 770.00 Included', '1649004100_pendant3.jpg', 'pendant'),
(16, 2, 'leaf inspired gold pendant', 19970, 'Gross Weight : 1.040g[18 Karat Yellow Gold]  Making Charges : 3940.00 + GST 650.00 Included', '1649004403_pendant4.jpg', 'pendant'),
(17, 2, 'charming yellow gold abstract pendant', 17890, 'Gross Weight : 3.148g[18 Karat yellow gold]  Making Charges : 3770.00 + GST 550.00 Included', '1649004618_pendant5.jpg', 'pendant'),
(18, 2, 'celestial yellow gold chrysanthemum pendant', 12450, 'Gross Weight : 2.258g[18 Karat yellow gold]  Making Charges : 2770.00 + GST 750.00 Included', '1649004761_pendant6.jpg', 'pendant'),
(19, 2, 'stunning gold pendant with ruby', 17750, 'Gross Weight : 2.650g[18 Karat Yellow Gold]  Making Charges : 2570.00 + GST 415.00 Included', '1649005569_pendant7.jpg', 'pendant'),
(20, 2, 'beatific yellow gold lord balaji pendant', 11780, 'Gross Weight : 2.120g[18 Karat Yellow Gold]  Making Charges : 2470.00 + GST 325.00 Included', '1649005746_pendant8.jpg', 'pendant'),
(21, 2, 'peacock inspired traditional pendant', 24750, 'Gross Weight : 1.140g[18 Karat Yellow Gold]  Making Charges : 5670.00 + GST 695.00 Included', '1649005914_pendant9.jpg', 'pendant'),
(25, 3, 'sapphire masterpiece', 101260, 'Gross Weight : 4.324g 18 Karat   Diamond Weight: 0.469 ct[Stone Clarity: SI2]   16.40 MM  Making Charges : 19270.00 + GST 2995.00 Included', '1649006607_ring1.jpg', 'rings'),
(26, 3, 'luxurious square ring', 67820, 'MEN 4.472g [18 Karat Yellow Gold]  Making Charges : 14270.00 + GST 1995.00 Included 18.80 MM', '1649006912_ring2.jpg', 'rings'),
(27, 3, 'splendid floral gold ring', 17780, 'Gross Weight : 3.472g [18 Karat]  Making Charges : 3670.00 + GST 475.00 Included   16.40 MM', '1649007113_ring3.jpg', 'rings'),
(28, 3, 'elegant slender solitaire ring', 287540, 'Gross Weight : 3.002g [18 Karat]  Making Charges : 10070.00 + GST 4775.00 Included  16.80 MM', '1649008453_ring4.jpg', 'rings'),
(29, 3, 'layered multi stone contemporary high polish diamond ring', 59980, 'Gross Weight : 2.402g [18 Karat]  Making Charges : 13070.00 + GST 1775.00 Included  16.40 MM', '1649008643_ring5.jpg', 'rings'),
(30, 3, 'minimalist geometric diamond band for men', 77850, 'Gross Weight : 7.462g [18 Karat Yellow Gold]  Making Charges : 15080.00 + GST 2275.00 Included   18.80 MM', '1649008840_ring6.jpg', 'rings'),
(31, 3, 'tantalizing rose gold and diamond studded finger ring', 170250, 'Gross Weight : 4.562g [18 Karat rose gold]  Making Charges : 28780.00 + GST 4975.00 Included  17.20 MM', '1649009107_ring7.jpg', 'rings'),
(32, 3, 'glorious cocktail look white gold and diamond ring ', 311120, 'Gross Weight : 8.120g [18 Karat White gold]  Making Charges : 70780.00 + GST 90275.00 Included  16.80 MM', '1649009341_ring8.jpg', 'rings'),
(33, 3, 'marvellous geometric solitaire ring for men', 287410, 'Gross Weight : 5.540g [18 Karat White gold]  Making Charges : 10480.00 + GST 8275.00 Included  18.80 MM', '1649009599_ring9.jpg', 'rings'),
(34, 4, 'unforgettable diamond mangalsutra', 217820, 'Gross Weight : 9.140g [18 Karat White gold]  Making Charges : 40580.00 + GST 6275.00 Included   30.48 MM', '1649010115_mangalsutra1.jpg', 'mangalsutra'),
(35, 4, 'regal magnificient diamond mangalsutra', 102450, 'Gross Weight : 6.144g [18 Karat White gold]  Making Charges : 20580.00 + GST 2975.00 Included  ', '1649010268_mangalsutra2.jpg', 'mangalsutra'),
(36, 4, 'decorated yellow gold half moon mangalsutra', 301200, 'Gross Weight : 16.144g [22 Karat] Making Charges : 90580.00 + GST 9975.00 Included', '1649010532_mangalsutra3.jpg', 'mangalsutra'),
(37, 4, 'beautiful yellow gold carved garland mangalsutra', 80410, 'Gross Weight : 12.744g [22 Karat White gold]  Making Charges : 15580.00 + GST 2345.00 Included  45.72 MM', '1649011704_mangalsutra4.jpg', 'mangalsutra'),
(38, 4, 'gold manga sutra for eternity', 34450, '43.18 CM  14 Karat Gold', '1649011959_mangalsutra5.jpg', 'mangalsutra'),
(39, 4, 'marvellous dainty gold mangalsutra', 47400, 'Gross Weight : 7.074g [22 Karat Yellow  gold]  Making Charges : 9580.00 + GST 1345.00 Included   45.72 CM', '1649012260_mangalsutra6.jpg', 'mangalsutra'),
(43, 5, 'floral bliss gold and diamond necklace', 264520, 'Gross Weight : 19.974g [18 Karat Yellow and gold]  Making Charges : 71580.00 + GST 8545.00 Included   Diamond Weight: 1.069 ct[Stone Clarity: SI2] ', '1649012892_Necklace1.jpg', 'Necklace'),
(44, 5, 'exquisite floral gold necklace', 90, 'Gross Weight : 15.974g [18 Karat Yellow and gold]  Making Charges : 48580.00 + GST 5945.00 Included   Diamond Weight: 0.764 ct[Stone Clarity: SI2] ', '1649013073_Necklace2.jpg', 'Necklace'),
(45, 5, 'mridula emerald and ruby necklace', 327200, 'Gross Weight : 47.970g [22 Karat Yellow] and gold]  Making Charges : 53580.00 + GST 9845.00 Included', '1649013342_Necklace3.jpg', 'Necklace'),
(46, 5, 'enchanting yellow gold floral necklace', 111260, 'Gross Weight : 16.860g[22 Karat Yellow] and gold]  Making Charges : 23580.00 + GST 3845.00 Included', '1649013578_Necklace4.jpg', 'Necklace'),
(49, 6, 'janya emerald and ruby bangle', 101111, 'Gross Weight : 16.960g[22 Karat Yellow]   Making Charges : 17580.00 + GST 3145.00 Included  60.00 MM', '1649014002_bangle1.jpg', 'bangle'),
(50, 6, 'stunning two toned gold and diamond bangl', 124560, 'Gross Weight : 12.970g[18 Karat Yellow and White gold]  Making Charges : 22580.00 + GST 3625.00 Included  60.00 MM', '1649014253_bangle2.jpg', 'bangle'),
(51, 6, 'bracelet for women with oval cut precious red gemstone', 64650, 'Gross Weight : 10.970g[14 Karat Yellow]  Making Charges : 12580.00 + GST 2625.00 Included  Height 60.08 MM Product Width 16.06 MM', '1649014610_bangle3.jpg', 'bangle'),
(55, 7, 'magnificent gold chain', 215430, 'Gross Weight : 33.125g[22 Karat Yellow]  Making Charges : 46590.00 + GST 6205.00 Included  45.72 CM', '1649014975_chain1.jpg', 'chain'),
(56, 7, 'majestic gold chain', 15999, 'Gross Weight : 26.025g[22 Karat Yellow]  Making Charges : 36550.00 + GST 7210.00 Included  45.72 CM', '1649015177_chain2.jpg', 'chain'),
(57, 7, 'splendid gold and kundan polki chain', 565, 'Gross Weight : 14.005g[18 Karat Yellow]  Making Charges : 19950.00 + GST 3410.00 Included  45.72 CM', '1649015354_chain3.jpg', 'chain'),
(58, 1, 'gold stud earrings [18 Karat Yellow Gold]', 20971, 'Gross Weight : 1.896 g Purity : 18.00 Making Charges 3977.00 + GST 604.41 Included', '1648994266_earrings1.jpg', 'earrings'),
(59, 1, 'Contemporary Diamond Stud Earrings [18 Karat Glossy Yellow Gold]', 27494, 'Gross Weight : 1.419g Purity : 18.00 Making Charges 5674.00 + GST 800.41 Included', '1648994393_earrings2.jpg', 'earrings'),
(60, 1, 'abstract appeal rose gold stud earrings', 47199, 'Gross Weight : 3.497g Purity : 14.00  Height 11 MM Product Width 10.5 MM', '1648994447_earrings3.jpg', 'earrings'),
(63, 1, 'lovely stud earrings [14 karat rose gold]', 27700, 'Gross Weight : 1.777g \r\nPurity : 14\r\nMaking Charges 5874.00 + GST 840.41 Included', '1648995098_earrings4.jpg', 'earrings'),
(64, 1, 'traditional alchemy diamond jhumka [18 Karat Yellow and White Gold]', 149970, 'Gross Weight : 9.277g \r\nPurity : 18\r\nMaking Charges 28283.00 + GST 4340.41 Included', '1648995204_earrings5.jpg', 'earrings'),
(65, 1, 'sleek fancy 18 Karat rose gold and diamond drop earrings', 99777, 'Gross Weight : 5.247g \r\nPurity : 18\r\nMaking Charges 17583.00 + GST 2770.00 Included', '1648995564_earrings6.jpg', 'earrings'),
(66, 1, 'magnificent antique gold stud earrings', 65640, 'Gross Weight : 9.664g \r\nPurity : 22 Karat Yellow Gold\r\nMaking Charges 14100.00 + GST 1950.00 Included', '1648995806_earrings7.jpg', 'earrings'),
(67, 1, 'charming floral jali work stud earrings', 47770, 'Gross Weight : 2.574g \r\n18 Karat Rose Gold\r\nMaking Charges : 9310.00 + GST 1350.00 Included', '1648996173_earrings8.jpg', 'earrings'),
(69, 3, 'platinum drop ring', 12000, 'MEN 5.472g [18 Karat Platinum Gold]  Making Charges : 14270.00 + GST ', '1674799399_d_boys ring6.png', 'ring'),
(71, 1, 'ABCD', 1200, 'qwwewrwrety', '1678993312_background.png', 'ring'),
(72, 5, 'Rings', 120000, 'Offer', '1739254236_Screenshot 2025-02-11 113742.png', 'as');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(4) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `email` text NOT NULL,
  `password` varchar(24) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` text NOT NULL,
  `address2` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(29, 'himanshu', 'donda', 'hd@gmail.com', 'donda@123', '7284858030', 'kaliyabid,bhavnagar', 'Gujrat-364002.'),
(39, 'himanshu', 'patel', 'hp@gmail.com', 'patel@123', '9933645120', 'Sardarnagar', 'bhavnagar'),
(42, 'jasani', 'jay', 'jasanijay342@gmail.com', 'Jay@033093', '9316590330', 'bhavnagar', 'bhavnagar'),
(50, 'paresh', 'chhabhad', 'pareshchhabhad@gmail.com', 'paresh@0330', '7275490749', 'bhavnagar', 'bhavnagar'),
(51, 'nitin', 'jasani', 'nitinjasani@gmail.com', 'nitin@0330', '9635485963', 'ahmedabad', 'ahmedabad'),
(53, 'jay', 'jasani', 'jasanijay@gmail.com', 'jay', '9316590330', 'BHAVNAGAR', 'bhavnagar'),
(54, 'Ashvin', 'Gohil', 'a.b.gohil1288@gmail.com', 'a.b.gohil1212', '7575084707', 'Bhavnagar', 'Bhavnagar'),
(55, 'Nirav', 'Shah', 'ssccs.project@gmail.com', 'nirav@123', '8866981290', 'SSCCS', 'Bhavnagar');

--
-- Triggers `user_info`
--
DELIMITER $$
CREATE TRIGGER `after_user_info_insert` AFTER INSERT ON `user_info` FOR EACH ROW BEGIN 
INSERT INTO user_info_backup VALUES(new.user_id,new.first_name,new.last_name,new.email,new.password,new.mobile,new.address1,new.address2);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user_info_backup`
--

CREATE TABLE `user_info_backup` (
  `user_id` int(4) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `email` text NOT NULL,
  `password` varchar(24) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` text NOT NULL,
  `address2` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_info_backup`
--

INSERT INTO `user_info_backup` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(42, 'jasani', 'jay', 'jasanijay342@gmail.com', 'Jay@033093', '9316590330', 'bhavnagar', 'bhavnagar'),
(43, 'jay', 'jasani', 'jasanijay@gmail.com', 'Jay@033093', '9316590330', 'bhavnagar', 'bhavnagar'),
(44, 'bhumit', 'jasani', 'jasanibhmit@gmail.com', 'jay@033093', '9316590330', 'bhavnagar', 'bhavnagar'),
(45, 'bhumit', 'jasani', 'jasanibhumit1@gmail.com', 'jay@033093', '9316590330', 'bhavnagar', 'bhavnagar'),
(48, 'paresh', 'chhabhad', 'pareshchhabhad@gmail.com', 'paresh@0330', '7285074907', 'surat', 'surat'),
(49, 'jasani', 'nitin', 'jasaninitin@gmail.com', 'nitin@123456', '9875641230', 'bhavnagar', 'bhavnagar'),
(50, 'paresh', 'chhabhad', 'pareshchhabhad@gmail.com', 'paresh@0330', '7275490749', 'bhavnagar', 'bhavnagar'),
(51, 'nitin', 'jasani', 'nitinjasani@gmail.com', 'nitin@0330', '9635485963', 'ahmedabad', 'ahmedabad'),
(52, 'Herish', 'Limbani', 'limbaniherish@gmail.com', 'herish@0330', '8916590330', 'bhavnagar', 'bhavnagar'),
(53, 'jay', 'chhabhad', 'jasanijay@gmail.com', 'qwerty@12', '9316590330', 'BHAVNAGAR', 'bhavnagar'),
(54, 'Ashvin', 'Gohil', 'a.b.gohil1288@gmail.com', 'a.b.gohil1212', '7575084707', 'Bhavnagar', 'Bhavnagar'),
(55, 'Nirav', 'Shah', 'ssccs.project@gmail.com', 'nirav@123', '8866981290', 'SSCCS', 'Bhavnagar');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_info`
--
ALTER TABLE `admin_info`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `orders_info`
--
ALTER TABLE `orders_info`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_products`
--
ALTER TABLE `order_products`
  ADD PRIMARY KEY (`order_pro_id`),
  ADD KEY `order_products` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `cat_id` (`cat_id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_info_backup`
--
ALTER TABLE `user_info_backup`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_info`
--
ALTER TABLE `admin_info`
  MODIFY `admin_id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `orders_info`
--
ALTER TABLE `orders_info`
  MODIFY `order_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `order_products`
--
ALTER TABLE `order_products`
  MODIFY `order_pro_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `user_info_backup`
--
ALTER TABLE `user_info_backup`
  MODIFY `user_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders_info`
--
ALTER TABLE `orders_info`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`);

--
-- Constraints for table `order_products`
--
ALTER TABLE `order_products`
  ADD CONSTRAINT `order_products` FOREIGN KEY (`order_id`) REFERENCES `orders_info` (`order_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `cat_id` FOREIGN KEY (`cat_id`) REFERENCES `categories` (`cat_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
