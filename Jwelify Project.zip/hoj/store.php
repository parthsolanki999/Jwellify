<?php
// Redirect to index.php
header("Location: index.php");
exit; // Ensure the script stops execution after redirection
?>
