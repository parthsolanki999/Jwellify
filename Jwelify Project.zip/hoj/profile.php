<?php 
	
	$sql = "SELECT * FROM user_info WHERE user_id='$_SESSION[uid]'";
	$run_query = mysqli_query($con,$sql);
	$count = mysqli_num_rows($run_query);
	$row = mysqli_fetch_array($run_query);
?>
	
	
	
	
	<div class="wait overlay">
        <div class="loader"></div>
    </div>
    <style>
    .input-borders{
        border-radius:30px;
    }
    </style>
				<!-- row -->
				
                <table width="80%" align="center" class="bg-warning">
					<tr>
						<th width="30%" style="padding-top:20px;">
							<h4>FIRST NAME  </h4>
						</th>
						<th width="60%" style="padding-top:20px;">
							<h4><?php echo ": &ensp;&ensp;&ensp;  ".$row[1]."  ". $row[2]; ?></h4>
						</th>
					</tr>
					<tr >
						<th width="20%" style="padding-top:20px;">
							<h4>EMAIL </h4>
						</th>
						<th width="70%" style="padding-top:20px;">
							<h4><?php echo ": &ensp;&ensp;&ensp;  ".$row[3]; ?></h4>
						</th>
					</tr>
					<tr>
						<th width="20%" style="padding-top:20px;">
							<h4>MOBILE NO </h4>
						</th>
						<th width="70%" style="padding-top:20px;">
							<h4><?php echo ": &ensp;&ensp;&ensp;  ".$row[5]; ?></h4>
						</th>
					</tr>
					<tr>
						<th width="20%" style="padding-top:20px;">
							<h4>ADDRESS-1 </h4>
						</th>
						<th width="70%" style="padding-top:20px;">
							<h4><?php echo ": &ensp;&ensp;&ensp;  ".$row[6]; ?></h4>
						</th>
					</tr>
					<tr>
						<th width="20%" style="padding-top:20px;">
							<h4>ADDRESS-2 </h4>
						</th>
						<th width="70%" style="padding-top:20px;">
							<h4><?php echo ": &ensp;&ensp;&ensp;  ".$row[7]; ?></h4>
						</th>
					</tr>
				
				</table>

					
				
				<!-- /row -->